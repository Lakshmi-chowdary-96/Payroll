package com.cg.payroll.client;
import java.util.Scanner;

import com.cg.payroll.Exceptions.AssociatedetailsNotFoundException;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
public class MainClass {
	public static void main(String args[]) {
		PayrollServices payrollServices=new PayrollServicesImpl();
		try {
			
			int associateId=payrollServices.acceptAssociateDetails(320000, "LAKSHMI", "Somineni", "'IT","A4", "HGFSGF4568", "lakshmi@gmail.com", new Salary(300000, 1200, 1500,9776), new BankDetails("HDFC", 434453,558936488));
					System.out.println("AssociateId:"+associateId);
				//	Associate associate=payrollServices.getAssociateDetails(101);
		} catch (Exception e) {
			e.printStackTrace();			
		}
		try {
			System.out.println( "NetSalary is"+" "+payrollServices.calculateNetSalary(102));
		}catch(Exception e1) {
			e1.printStackTrace();
			
		}
		/*
		Scanner scanner=new Scanner(System.in);
        int choice = 0,associateId;
        System.out.println("Associate Management System");
        do {
            System.out.println(
                    "___________________\nPlease enter ur choice : \n1. Add associate\n2. Find associate\n3. Calculate salary\n4. Display all assocciates\n5. Exit\n___________________");
            choice = scanner.nextInt();
            scanner.nextLine();
            switch (choice) {
            case 1:
                System.out.println("Enter new associate details : ");
                System.out.println("First Name : ");
                String firstName = scanner.nextLine();
                System.out.println("Last Name : ");
                String lastName = scanner.nextLine();
                System.out.println("Department : ");
                String department = scanner.nextLine();
                System.out.println("Designation : ");
                String designation = scanner.nextLine();
                System.out.println("Pancard no. : ");
                String pancard = scanner.nextLine();
                System.out.println("Email Id : ");
                String emailId = scanner.nextLine();
                System.out.println("Basic Salary : ");
                int basicSalary = scanner.nextInt();
                System.out.println("EPF Amount : ");
                int epf = scanner.nextInt();
                System.out.println("Company PF Amount :");
                int companyPf = scanner.nextInt();
                System.out.println("Yearly Investment Under 80C : ");
                int yearlyInvestmentUnder80C = scanner.nextInt();
                System.out.println("Bank Account no. :");
                int accountNumber = scanner.nextInt();
                scanner.nextLine();
                System.out.println("Bank Name : ");
                String bankName = scanner.next();
                System.out.println("Bank IFSC Code : ");
                String ifscCode = scanner.next();
                associateId = payrollServices.acceptAssociateDetails(yearlyInvestmentUnder80C, firstName, lastName, department,
                        designation, pancard, emailId, basicSalary, epf, companyPf, accountNumber, bankName, ifscCode);
                break;

            case 2:
                System.out.println("Enter Associate Id to search");
                associateId = scanner.nextInt();
                try {
                    System.out.println(
                            "Associate details : \n" + payrollServices.getAssociateDetails(associateId).toString());
                } catch (AssociatedetailsNotFoundException e) {
                    e.printStackTrace();
                }
                break;

            case 3:
                System.out.println("Enter Associate Id to search");
                associateId = scanner.nextInt();
                try {
                    System.out.println("Associate salary : " + payrollServices.calculateNetSalary(associateId));
                } catch (AssociatedetailsNotFoundException e) {
                    e.printStackTrace();
                }
                break;

            case 4:
                System.out.println("All Associate Details");
                Associate[] associates = payrollServices.getAllAssociateDetails();
                try {
                    for (Associate associate : associates)
                        if (associate != null)
                            System.out.println("___________________________________________\n"
                                    + payrollServices.getAssociateDetails(associate.getAssociateID()).toString());
                } catch (AssociatedetailsNotFoundException e) {
                    e.printStackTrace();
                }
                break;

            case 5:
                System.out.println("Exited");
                System.exit(0);

            default:
                System.out.println("Invalid Choice...");
                break;
            }
        } while (choice != 5);	*/
	}
						
}


