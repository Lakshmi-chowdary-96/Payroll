package com.cg.payroll.services;
import java.util.List;

import com.cg.payroll.Exceptions.AssociatedetailsNotFoundException;
import com.cg.payroll.beans.*;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.daoservices.AssociateDAOImpl;
public class PayrollServicesImpl  implements PayrollServices{
	//Associate associate=new Associate(yearlyInvestmmentUnder80C, firstName, lastName, department, designation, pancard, emailId, salary, bankDetails);
	private AssociateDAO associateDAO=new AssociateDAOImpl();
	public int acceptAssociateDetails(int yearlyInvestmmentUnder80C, String firstName, String lastName, String department,
			String designation, String pancard, String emailId, Salary salary, BankDetails bankDetails) {
		Associate associate=new Associate(yearlyInvestmmentUnder80C, firstName, lastName, department, designation, pancard, emailId, salary, bankDetails);

		associateDAO.save(associate);
		return associate.getAssociateID();
	}


	public int calculateNetSalary(int associateId) throws AssociatedetailsNotFoundException {
		Associate associate=this.getAssociateDetails(associateId);
		if(associate==null)throw new AssociatedetailsNotFoundException("Id not found");
		int annualTax=0;
		int hra=(associate.getSalary().getBasicSalary()*40)/100;
		int conveyanceAllownace=(associate.getSalary().getBasicSalary()*30)/100;
		int otherAllowance=(associate.getSalary().getBasicSalary()*20)/100;
		int personalAllowance=(associate.getSalary().getBasicSalary()*20)/100;
		int grossSalary=associate.getSalary().getBasicSalary()+hra+conveyanceAllownace+otherAllowance+personalAllowance;
		int annualSalary=grossSalary*12;
		
		int taxable=annualSalary-associate.getYearlyInvestmmentUnder80C()-associate.getSalary().getBasicSalary()-associate.getSalary().getEpf()*12-associate.getSalary().getCompanyPf()*12;
		if(taxable<250000)
			annualTax=0;
		if(taxable>250000&&taxable<=500000)
			annualTax=annualTax+((taxable-250000*10))/100;
		if(taxable>500000&&taxable<=1000000)
			annualTax=250000+((taxable-500000*20/100));
		if(taxable>100000)
			annualTax=125000+((taxable-1000000*30)/100);
		int monthlyTax=annualTax/12;
		int netSalary=grossSalary-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf()-monthlyTax;
		return netSalary;


	}

	
	public Associate getAssociateDetails(int associateId) throws AssociatedetailsNotFoundException {
		Associate associate=associateDAO.findOne(associateId);
		if(associate==null)throw new AssociatedetailsNotFoundException("Associate details not found for associateId"+associate);
		return associate;

	}

	@Override
	public List<Associate> getAllAssociateDetails() {
		// TODO Auto-generated method stub
		return null;
	}


	
	/*public int acceptAssociateDetails(int yearlyInvestmentUnder80C, String firstName, String lastName,
			String department, String designation, String pancard, String emailId, int basicSalary, int epf,
			int companyPf, int accountNumber, String bankName, String ifscCode) {
		// TODO Auto-generated method stub
		return 0;
	}*/




}
