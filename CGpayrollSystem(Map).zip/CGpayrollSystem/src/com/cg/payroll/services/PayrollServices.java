package com.cg.payroll.services;
import java.util.List;

import com.cg.payroll.Exceptions.AssociatedetailsNotFoundException;
import com.cg.payroll.beans.*;
public interface PayrollServices {
	int acceptAssociateDetails(int yearlyInvestmmentUnder80C, String firstName, String lastName, String department,
			String designation, String pancard, String emailId, Salary salary, BankDetails bankDetails);
	
	int calculateNetSalary(int associateId)throws AssociatedetailsNotFoundException;
	 Associate getAssociateDetails(int AssociateId)throws AssociatedetailsNotFoundException;
	 //Associate[]getAllAssociateDetails();
	List<Associate>getAllAssociateDetails();
	 /*int acceptAssociateDetails(int yearlyInvestmentUnder80C, String firstName, String lastName, String department,
			String designation, String pancard, String emailId, int basicSalary, int epf, int companyPf,
			int accountNumber, String bankName, String ifscCode);
	*/
	 
}
