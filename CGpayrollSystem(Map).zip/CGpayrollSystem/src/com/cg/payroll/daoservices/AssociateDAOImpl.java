package com.cg.payroll.daoservices;
import java.util.List;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.payrollutil.PayrollUtil;
public class AssociateDAOImpl implements AssociateDAO {
	@Override
	public Associate save(Associate associate) {
		associate.setAssociateID(PayrollUtil.getASSOCIATIVE_ID_COUNTER());
		PayrollUtil.associates.put(associate.getAssociateID(),associate);
		//PayrollUtil.associates[PayrollUtil.getASSOCIATE_IDX()]=associate;
		//associates[PayrollUtil.getASSOCIATE_IDX()]=associate;              
		return associate;
	}

	@Override
	public boolean update(Associate associate) {
		//PayrollUtill.associates.put(associate.getAssociateID(),associate);
		return true;
	}

	@Override
	public Associate findOne(int associateId) {
		//for(Associate associate:PayrollUtil.associates)
		//if(associate!=null&&associate.getAssociateID()==associateId)
		//return associate;
		//return null;
		return PayrollUtil.associates.get(associateId);
	}

	@Override
	public List<Associate>  findAll() {
		// TODO Auto-generated method stub
		return null;
	}

}
