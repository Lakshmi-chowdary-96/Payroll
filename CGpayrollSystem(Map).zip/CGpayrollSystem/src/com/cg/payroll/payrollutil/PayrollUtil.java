package com.cg.payroll.payrollutil;
import java.util.HashMap;

import com.cg.payroll.beans.Associate;
public class PayrollUtil {
	private static int ASSOCIATE_ID_COUNTER=101;
	//private static int ASSOCIATE_IDX=0;
	//public static Associate[] associates=new Associate[10];
	public static HashMap<Integer,Associate> associates=new HashMap<>();
	public static int getASSOCIATIVE_ID_COUNTER() {
		return ++ASSOCIATE_ID_COUNTER;
	
	//public static int getASSOCIATE_IDX() {
		//return ASSOCIATE_IDX++;
	}
}
	
	


