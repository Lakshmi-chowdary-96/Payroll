package com.cg.payroll.beans;
public class BankDetails {
	private String bankName;
	private int accountNumber,IFSCCode;
public BankDetails() {
	// TODO Auto-generated constructor stub
}

public BankDetails(String bankName, int accountNumber, int IFSCCode) {
	super();
	this.bankName = bankName;
	this.accountNumber = accountNumber;
	this.IFSCCode = IFSCCode;
}
public String getBankName() {
	return bankName;
}
public void setBankName(String bankName) {
	this.bankName = bankName;
}

public int getAccountNumber() {
	return accountNumber;
}
public void setAccountNumber(int accountNumber) {
	this.accountNumber = accountNumber;
}
public int getIFSCCode() {
	return IFSCCode;
}
public void setIFSCCode(int iFSCCode) {
	IFSCCode = iFSCCode;
}

	
		
	}

	
