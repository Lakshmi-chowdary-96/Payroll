package com.cg.payroll.beans;

public class Salary{
	private int basicSalary,hra,epf;
	private int companyPf;
	public Salary() {}
	public Salary(int basicSalary, int hra, int epf,int companyPf)
			 {

		this.basicSalary = basicSalary;
		this.hra = hra;
		
		
		this.epf = epf;
		this.companyPf=companyPf;
		
	}
	public int getBasicSalary() {
		return basicSalary;
	}
	public void setBasicSalary(int basicsalary) {
		this.basicSalary = basicSalary;
	}
	public int getHra() {
		return hra;
	}
	public void setHra(int hra) {
		this.hra = hra;
	}
	public int getCompanyPf() {
		return companyPf;
	}
	public void setCompanyPf(int companyPf) {
		this.companyPf = companyPf;
	}
	public int getEpf() {
		return epf;
	}
	public void setEpf(int epf) {
		this.epf = epf;
	}
	
}
	
