package com.cg.payroll.services;
import com.cg.payroll.Exceptions.AssociatedetailsNotFoundException;
import com.cg.payroll.beans.*;
public interface PayrollServices {
	int acceptAssociateDetails(int yearlyInvestmmentUnder80C, String firstName, String lastName, String department,
			String designation, String pancard, String emailId, Salary salary, BankDetails bankDetails);
	 int calculateNetSalary(int associateId)throws AssociatedetailsNotFoundException;
	 Associate getAssociateDetails(int AssociateId)throws AssociatedetailsNotFoundException;
	 Associate[]getAllAssociateDetails();
	
	 
}
