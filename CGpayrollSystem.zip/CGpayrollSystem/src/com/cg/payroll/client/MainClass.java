package com.cg.payroll.client;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
public class MainClass {
	public static void main(String args[]) {
		PayrollServices payrollServices=new PayrollServicesImpl();
		try {
			
			int associateId=payrollServices.acceptAssociateDetails(320000, "LAKSHMI", "Somineni", "'IT","A4", "HGFSGF4568", "lakshmi@gmail.com", new Salary(300000, 1200, 1500,9776), new BankDetails("HDFC", 434453,558936488));
					System.out.println("AssociateId:"+associateId);
				//	Associate associate=payrollServices.getAssociateDetails(101);
		} catch (Exception e) {
			e.printStackTrace();			
		}
		try {
			System.out.println( "NetSalary is"+" "+payrollServices.calculateNetSalary(102));
		}catch(Exception e1) {
			e1.printStackTrace();
			
		}
		
				
	}
						
}


